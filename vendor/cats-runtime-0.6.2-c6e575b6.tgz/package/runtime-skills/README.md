# Runtime Skill Library

> Runtime-owned skill content catalog for `cats-runtime`.

## Purpose

`cats-runtime/runtime-skills/` is the canonical library of execution-ready `SKILL.md`
packages that the runtime can validate, resolve, materialize, and report in
session metadata.

This directory is:

- runtime-owned content
- family-organized for authoring and review
- compatible with the existing runtime skill validator

This directory is not:

- a second product-side skill catalog
- the runtime injection/materialization engine
- a runtime dependency on any sibling or submodule role library

## Authoring Reference Boundary

The source library carries a preview content manifest. Preview-only managed
product skills live in the reserved `preview/` subtree; the ordinary library
remains available to both profiles. Normal npm artifacts omit that subtree and
the source manifest, defaulting to release. Desktop staging selects its profile
explicitly. Content eligibility grants no repository write, model usage or
publication authority. See [PLAN-041](../docs/plans/PLAN-041-preview-skill-content-policy.md)
for retained-context provenance, fresh-session recovery and the next-minor
compatibility requirement.

`agency-agents/` may exist at the monorepo root as an authoring/reference
source, but shipped `cats-runtime` skills must remain local packages owned by
this repo. Do not import from `agency-agents` at runtime.

## Layout

```text
runtime-skills/
  orchestration/
    coordinator/
      SKILL.md
  work/
    product-manager/
      SKILL.md
  chat/
    companion/
      SKILL.md
  code/
    advanced-programmer-runtime/
      SKILL.md
```

Requested runtime skill ids remain the leaf package names such as
`coordinator`, `product-manager`, or `advanced-programmer-runtime`.

## Frontmatter Contract

All shipped runtime-owned skills should declare this richer metadata:

```yaml
---
name: product-manager
description: Product management skill for scope control and requirements framing.
family: work
slug: product-manager
role: product_manager
packageKind: role
version: 1.0.0
capabilityTags:
  - scope-control
  - requirements-framing
productTags:
  - product
  - planning
deliveryHints:
  - filesystem
  - instructions
recommendedCompanions:
  - companion-mentor
---
```

Field notes:

- `name`: required skill id and directory name
- `family`: taxonomy grouping used by the runtime catalog
- `slug`: stable role/library slug
- `role`: machine-readable role identifier
- `packageKind`: `base`, `role`, or `bundle`
- `version`: content package version
- `capabilityTags`: what the skill is good at
- `productTags`: contexts/products likely to consume it
- `deliveryHints`: preferred runtime delivery shapes
- `recommendedCompanions`: optional pairing hints for higher-level products

Custom local skills may omit the richer metadata and still pass the baseline
runtime-managed skills validator, but runtime-owned library packages should not.

## Verification Gate

`npm run verify:skills` is the runtime-owned publish gate for shipped
`cats-runtime/runtime-skills/` packages.

It now requires every shipped runtime-owned skill to explicitly declare these
frontmatter fields instead of relying on catalog-derived defaults:

- `family`
- `slug`
- `role`
- `packageKind`
- `version`
- `capabilityTags`
- `productTags`
- `deliveryHints`

`recommendedCompanions` remains optional. When a shipped skill has no pairing
hints, it may omit the field or declare an empty array explicitly.

## Families

### `orchestration`

| Skill | Package Kind | Focus |
|-------|--------------|-------|
| `a2a-handoff` | `role` | bounded handoff preparation across protocol, project-memory, and skill layers |
| `project-memory-sync` | `role` | durable markdown-state synchronization during collaboration |
| `orchestrator` | `role` | high-level decomposition and delegation |
| `coordinator` | `role` | sequencing and dependency management |
| `dispatcher` | `role` | work routing and capability matching |
| `incident-commander` | `role` | degraded-state stabilization and evidence-first triage |
| `delivery-auditor` | `base` | delivery/readiness verification |

Collaboration note:

- these two skills are procedural helpers for same-environment repo work
- they must point agents back to `AGENTS.md`, `docs/AGENT-GUIDE.md`, and
  durable markdown memory
- they must not become a second hidden state store

### `work`

| Skill | Package Kind | Focus |
|-------|--------------|-------|
| `ceo` | `role` | executive direction and tradeoffs |
| `sales` | `role` | qualification and next-step control |
| `product-manager` | `role` | scope and requirements |
| `project-manager-agile` | `role` | iterative delivery hygiene |
| `project-manager-waterfall` | `role` | milestone sequencing |
| `ux` | `role` | interaction and flow clarity |
| `art-designer` | `role` | visual direction |
| `architect` | `role` | system boundaries and long-lived design |
| `coder` | `role` | implementation and debugging |
| `automation-tester` | `role` | regression automation |
| `code-reviewer` | `role` | bug/risk review |
| `qa` | `role` | acceptance and release risk |
| `marketer` | `role` | positioning and messaging |
| `hr` | `role` | people/policy communication |
| `secretary` | `role` | administrative follow-through |
| `intern` | `role` | bounded support work |

### `chat`

| Skill | Package Kind | Focus |
|-------|--------------|-------|
| `companion` | `base` | memory continuity and daily presence |
| `companion-gentle` | `role` | calm, low-pressure support |
| `companion-playful` | `role` | lightness and energy |
| `companion-guardian` | `role` | boundaries and protective support |
| `companion-mentor` | `role` | reflective growth-oriented guidance |

### `code`

| Skill | Package Kind | Focus |
|-------|--------------|-------|
| `repo-maintainer` | `base` | safe narrow-scope code changes |
| `advanced-programmer-backend` | `role` | backend contracts and production safety |
| `advanced-programmer-frontend` | `role` | UI/state implementation integrity |
| `advanced-programmer-systems` | `role` | hosts, packaging, and process supervision |
| `advanced-programmer-runtime` | `role` | runtime seams and lifecycle integrity |

## Preview supplement

The source/preview library includes three additional self-contained packages:

| Skill | Purpose |
|-------|---------|
| `cats-inc-development` | Authorized Cats source changes, isolated candidates, independent review and checkpoints |
| `cats-platform-operation` | Practice with observed product state, actual tools and authoritative results |
| `cats-practice-and-distill` | Evidence-backed candidate lessons, fixed evaluation and independent promotion |

Their essential workflow is inline for instruction delivery; optional reference
files travel with filesystem delivery and participate in the package digest.
Normal release/npm inventory remains the original 33 packages. The source/preview
inventory has 36. These packages do not grant tool access or permissions, launch
practice on their own, or replace ordinary Catlas/Orchestrator knowledge.

## Delivery

The runtime resolves and delivers these product packages when a session requests them.
Codex filesystem delivery also supports a Runtime-owned Git worktree when its
session identity, physical path and source Git common directory match. Existing
repository ignore rules must cover every skill/resource and preview marker;
tracked targets, symlinks, junctions and hardlinks reject delivery. Runtime does
not change Git configuration or the index to make this possible. Source workspaces
and unverified worktrees still degrade to instructions (and fail strict mode).
Provider access, permission mode and tool grants are independent and unchanged.
Each create/message/resume hydration revalidates delivery; messages trigger
hydration when skills or hydration context metadata are supplied. Explicit
version/fingerprint requests must be repeated when the caller requires the same
package across messages. An ordinary message without either keeps its existing state.
Run `npm run verify:skills` after editing the library. Repository agent-sync helpers
read the separate developer `skills/` root and never copy this library.

---

*This directory follows the [Agent Skills](https://agentskills.io) standard while adding runtime-owned library metadata for `cats-runtime`.*
